/**
 * Background service that monitors weight goals and sends SMS notifications.
 * Runs continuously and checks daily for goal achievement.
 */

package com.zybooks.weighttracker360;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

public class NotificationService extends Service {

    private static final String TAG = "NotificationService";
    private Timer timer;
    private SharedPreferences sharedPreferences;
    private DatabaseHelper databaseHelper;

    // Initializes the service by setting up shared preferences and database connections
    @Override
    public void onCreate() {
        super.onCreate();
        sharedPreferences = getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);
        databaseHelper = new DatabaseHelper(this);
    }

    // Handles service start requests
    // Initializes notification checking and returns START_STICKY to ensure service restarts if terminated
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startNotificationCheck();
        return START_STICKY;
    }

    // Starts a daily timer to check weight goals
    private void startNotificationCheck() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                checkWeightGoalAndNotify();
            }
        }, 0, 24 * 60 * 60 * 1000); // Check once a day
    }

    // Checks if the user has reached their weight goal
    // Will proceed if latest weight entry is within 0.5 pounds of goal and SMS notifications are enabled
    private void checkWeightGoalAndNotify() {
        boolean smsEnabled = sharedPreferences.getBoolean("sms_enabled", false);
        if (!smsEnabled) {
            return;
        }

        float weightGoal = sharedPreferences.getFloat("weight_goal", 0f);
        if (weightGoal == 0f) {
            return;
        }

        // Get the latest weight entry
        float latestWeight = databaseHelper.getLatestWeight();
        if (latestWeight == 0f) {
            return;
        }

        // Check if the goal is reached
        if (Math.abs(latestWeight - weightGoal) <= 0.5) { // Within 0.5 kg of the goal
            sendSmsNotification("Congratulations! You've reached your weight goal of " + weightGoal + " lb!");
        }
    }

    // Sends an SMS notification to the user's registered phone number
    // Android Emulator I used 15555215554 to test
    private void sendSmsNotification(String message) {
        String phoneNumber = sharedPreferences.getString("phone_number", "");
        if (phoneNumber.isEmpty()) {
            Log.e(TAG, "No phone number set for notifications");
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d(TAG, "SMS notification sent successfully");
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS notification", e);
        }
    }

    // Cleans up resources when service is destroyed
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }

    // Required for Service implementation
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

/**
 * Activity for managing user preferences including SMS notifications,
 * weight goals, and phone number settings.
 * Handles SMS permissions and notification service management.
 */


package com.zybooks.weighttracker360;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private Switch smsNotificationSwitch;
    private EditText weightGoalEditText;
    private EditText phoneNumberEditText;
    private Button saveButton;
    private SharedPreferences sharedPreferences;


    // Initializes the settings screen and loads saved preferences
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        smsNotificationSwitch = findViewById(R.id.smsNotificationSwitch);
        weightGoalEditText = findViewById(R.id.weightGoalEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        saveButton = findViewById(R.id.saveButton);

        sharedPreferences = getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);

        // Load saved preferences
        boolean smsEnabled = sharedPreferences.getBoolean("sms_enabled", false);
        float weightGoal = sharedPreferences.getFloat("weight_goal", 0f);
        String phoneNumber = sharedPreferences.getString("phone_number", "");

        smsNotificationSwitch.setChecked(smsEnabled);
        weightGoalEditText.setText(String.valueOf(weightGoal));
        phoneNumberEditText.setText(phoneNumber);

        // Configuration ClickListener for the save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });
    }

    // Saves user settings to SharedPreferences
    // Handles SMS permission checks, validates weight goal input, and manages the notification service state
    // Starts or stops the NotificationService based on SMS notification toggle
    private void saveSettings() {
        boolean smsEnabled = smsNotificationSwitch.isChecked();
        String weightGoalStr = weightGoalEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString();

        if (smsEnabled && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("sms_enabled", smsEnabled);
            editor.putString("phone_number", phoneNumber);

            if (!weightGoalStr.isEmpty()) {
                try {
                    float weightGoal = Float.parseFloat(weightGoalStr);
                    editor.putFloat("weight_goal", weightGoal);
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight goal", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            editor.apply();

            // Start or stop the NotificationService based on the new setting
            Intent serviceIntent = new Intent(this, NotificationService.class);
            if (smsEnabled) {
                startService(serviceIntent);
            } else {
                stopService(serviceIntent);
            }
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
            finish();
        }
    }


    // Handles the result of SMS permission requests
    // If permission is granted, proceeds with saving settings
    // If denied, disables SMS notifications and updates the UI
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSettings();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                smsNotificationSwitch.setChecked(false);
            }
        }
    }
}

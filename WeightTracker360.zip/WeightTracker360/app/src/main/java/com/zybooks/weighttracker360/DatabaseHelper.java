/**
 * Helper class for managing SQLite database operations in the Weight Tracker app.
 * Handles user authentication and weight entry storage.
 */

package com.zybooks.weighttracker360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // User table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Weight entries table
    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_USER_ID = "user_id";

    // Create users table query
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USERNAME + " TEXT UNIQUE,"
            + COLUMN_PASSWORD + " TEXT"
            + ")";

    // Create weight entries table query
    private static final String CREATE_WEIGHT_ENTRIES_TABLE = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_WEIGHT + " REAL,"
            + COLUMN_DATE + " DATETIME DEFAULT CURRENT_TIMESTAMP,"
            + COLUMN_USER_ID + " INTEGER,"
            + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + ")"
            + ")";

    // Constructor for the database with specified name and version
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database tables when database is first created
    // Sets up tables for users and weight entries
    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_USERS_TABLE);
            db.execSQL(CREATE_WEIGHT_ENTRIES_TABLE);
            Log.d(TAG, "Database tables created successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error creating database tables", e);
        }
    }

    // Handles database upgrades by dropping and recreating tables
    // Called when database version is increased
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Add new user to the database
    // Return True if user added, false otherwise
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Verifies users credentials against the database
    // Return true if match, otherwise false
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    // Add new weight entry for specific user
    // Returns the row ID of the new entry
    public long addWeightEntry(float weight, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_USER_ID, userId);
        return db.insert(TABLE_WEIGHT_ENTRIES, null, values);
    }

    // Updates an existing weight entry with a new weight value
    public boolean updateWeightEntry(long id, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weight);
        int rowsAffected = db.update(TABLE_WEIGHT_ENTRIES, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    // Deletes a weight entry from the database.
    public boolean deleteWeightEntry(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_WEIGHT_ENTRIES, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    // Retrieves the most recent weight entries for a specific user.
    public List<WeightEntry> getWeightEntries(long userId) {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_ID + ", " + COLUMN_WEIGHT + ", " + COLUMN_DATE +
                " FROM " + TABLE_WEIGHT_ENTRIES +
                " WHERE " + COLUMN_USER_ID + " = ? ORDER BY " + COLUMN_DATE + " DESC LIMIT 10";

        try (Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)})) {
            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(0);
                    float weight = cursor.getFloat(1);
                    String date = cursor.getString(2);
                    entries.add(new WeightEntry(id, weight, date));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving weight entries", e);
        }

        return entries;
    }

    // Retrieves the user ID associated with a given username
    public long getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        long userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getLong(0);
        }
        cursor.close();
        return userId;
    }

    // Retrieves the most recent weight entry from the database
    public float getLatestWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_WEIGHT + " FROM " + TABLE_WEIGHT_ENTRIES +
                " ORDER BY " + COLUMN_DATE + " DESC LIMIT 1";
        Cursor cursor = db.rawQuery(query, null);
        float latestWeight = 0f;
        if (cursor.moveToFirst()) {
            latestWeight = cursor.getFloat(0);
        }
        cursor.close();
        return latestWeight;
    }
}

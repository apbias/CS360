/**
 * BroadcastReceiver that starts the NotificationService when the device completes its boot process.
 * This ensures that weight goal notifications continue to work even after device restarts.
 */

package com.zybooks.weighttracker360;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            Intent serviceIntent = new Intent(context, NotificationService.class);
            context.startService(serviceIntent);
        }
    }
}

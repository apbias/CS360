/**
 * Data model class representing a single weight entry.
 * Stores weight measurement data including ID, weight value, and date.
 */

package com.zybooks.weighttracker360;

public class WeightEntry {
    private long id;
    private float weight;
    private String date;

    // Constructor for weight entry
    public WeightEntry(long id, float weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Return unique identifier
    public long getId() {
        return id;
    }

    // Return weight value
    public float getWeight() {
        return weight;
    }

    // Return the date
    public String getDate() {
        return date;
    }

    // String representation of the weight entry
    @Override
    public String toString() {
        return weight + " lb on " + date;
    }
}

/**
 * Main dashboard activity that displays weight entries, allows users to add/modify entries,
 * and shows a graph of weight progress over time.
 */


package com.zybooks.weighttracker360;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private Button buttonAddWeight;
    private ListView listViewWeightEntries;
    private LineChart chart;
    private DatabaseHelper databaseHelper;
    private long userId;
    private List<WeightEntry> weightEntries;
    private ArrayAdapter<WeightEntry> adapter;
    private SharedPreferences sharedPreferences;


    // Initializes the dashboard and all components such as UI, initial data, toolbar, database connections,
    // weight entry list and chart.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        databaseHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);

        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        listViewWeightEntries = findViewById(R.id.listViewWeightEntries);
        chart = findViewById(R.id.chart);


        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        userId = databaseHelper.getUserId(username);

        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightEntry();
            }
        });

        listViewWeightEntries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showUpdateDeleteDialog(weightEntries.get(position));
            }
        });

        // Disable ScrollView's internal scrolling when touching ListView
        listViewWeightEntries.setOnTouchListener((v, event) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        });

        loadWeightEntries();
        setupChart();
    }

    // Add weight entry to the database, validates input.
    private void addWeightEntry() {
        String weightEntry = editTextWeight.getText().toString().trim();
        if (!weightEntry.isEmpty()) {
            try {
                float weight = Float.parseFloat(weightEntry);
                long result = databaseHelper.addWeightEntry(weight, userId);
                if (result != -1) {
                    Toast.makeText(DashboardActivity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                    editTextWeight.setText("");
                    loadWeightEntries();
                } else {
                    Toast.makeText(DashboardActivity.this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(DashboardActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(DashboardActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
        }
    }

    // Load weight entries from the database for the current user, updates the ListView,
    // and refreshes weight chart
    private void loadWeightEntries() {
        weightEntries = databaseHelper.getWeightEntries(userId);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightEntries);
        listViewWeightEntries.setAdapter(adapter);
        updateChart();
    }

    // Show dialog for updating or deleting a selected weight entry
    private void showUpdateDeleteDialog(final WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update or Delete Entry");
        builder.setMessage("Weight: " + entry.getWeight() + " lb\nDate: " + entry.getDate());
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showUpdateDialog(entry);
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteWeightEntry(entry);
            }
        });
        builder.setNeutralButton("Cancel", null);
        builder.show();
    }

    // Show dialog for updating the weight of an existing entry.
    // Has Input validation and error handling
    private void showUpdateDialog(final WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Weight");
        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(entry.getWeight()));
        builder.setView(input);
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    float newWeight = Float.parseFloat(input.getText().toString());
                    updateWeightEntry(entry.getId(), newWeight);
                } catch (NumberFormatException e) {
                    Toast.makeText(DashboardActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // Update an existing weight entry with new value. Refreshes the display on success
    private void updateWeightEntry(long id, float newWeight) {
        boolean success = databaseHelper.updateWeightEntry(id, newWeight);
        if (success) {
            Toast.makeText(this, "Weight entry updated", Toast.LENGTH_SHORT).show();
            loadWeightEntries();
        } else {
            Toast.makeText(this, "Failed to update weight entry", Toast.LENGTH_SHORT).show();
        }
    }

    // Deletes weight entry and refreshes display
    private void deleteWeightEntry(WeightEntry entry) {
        boolean success = databaseHelper.deleteWeightEntry(entry.getId());
        if (success) {
            Toast.makeText(this, "Weight entry deleted", Toast.LENGTH_SHORT).show();
            loadWeightEntries();
        } else {
            Toast.makeText(this, "Failed to delete weight entry", Toast.LENGTH_SHORT).show();
        }
    }

    // Inflates the options menu in the toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    // Handles selections of menu items in the toolbar
    // Currently handles navigation to the settings screen
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(DashboardActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Initializes the weight progress chart with appropriate settings
    private void setupChart() {
        chart.getDescription().setEnabled(false);
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);

        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setDrawGridLines(true);

        chart.getAxisRight().setEnabled(false);
    }

    // Updates the chart with current weight data and goal weight line to be displayed on the chart
    private void updateChart() {
        List<Entry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd", Locale.getDefault());

        Collections.reverse(weightEntries);

        for (int i = 0; i < weightEntries.size(); i++) {
            WeightEntry entry = weightEntries.get(i);
            entries.add(new Entry(i, entry.getWeight()));
            try {
                Date date = inputFormat.parse(entry.getDate());
                labels.add(outputFormat.format(date));
            } catch (ParseException e) {
                e.printStackTrace();
                labels.add("");
            }
        }

        LineDataSet dataSet = new LineDataSet(entries, "Weight");
        dataSet.setColor(Color.BLUE);
        dataSet.setCircleColor(Color.BLUE);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);

        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setLabelRotationAngle(45);

        // Add goal weight line
        float goalWeight = sharedPreferences.getFloat("weight_goal", 0f);
        if (goalWeight > 0) {
            LineDataSet goalDataSet = new LineDataSet(createGoalEntries(goalWeight, weightEntries.size()), "Goal Weight");
            goalDataSet.setColor(Color.YELLOW);
            goalDataSet.setDrawCircles(false);
            goalDataSet.setLineWidth(2f);
            lineData.addDataSet(goalDataSet);
        }

        chart.invalidate();
    }

    // Creates a list of entries representing the goal weight line to be displayed on the chart.
    private List<Entry> createGoalEntries(float goalWeight, int size) {
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            entries.add(new Entry(i, goalWeight));
        }
        return entries;
    }

}
